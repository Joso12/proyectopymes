import Pyme from "../models/Pyme.js";

export const renderPymeForm = (req, res) => res.render("pymes/new-pyme");

export const createNewPyme = async (req, res) => {
  const { nombre_pyme, telefono, correo, ubicacion, descripcion, categoria } = req.body;
  const errors = [];
  if (!nombre_pyme) {
    errors.push({ text: "Porfavor ingrese nombre de su pyme." });
  }
  if (!telefono) {
    errors.push({ text: "Porfavor ingrese telefono de contacto" });
  }
  if (!correo) {
    errors.push({ text: "Porfavor ingrese correo" });
  }
  if (!ubicacion) {
    errors.push({ text: "Porfavor ingrese ubicacion" });
  }
  if (!descripcion) {
    errors.push({ text: "Porfavor ingrese descripcion" });
  }
  if (!categoria) {
    errors.push({ text: "Porfavor ingrese su categoria" });
  }
  if (errors.length > 0)
    return res.render("pymes/new-pyme", {
      errors,
      nombre_pyme,
      telefono,
      correo,
      ubicacion,
      descripcion,
      categoria,
    });

  const newPyme = new Pyme({ nombre_pyme, telefono, correo, ubicacion, descripcion, categoria });
  newPyme.user = req.user.id;
  await newPyme.save();
  req.flash("success_msg", "Pyme agregada correctamente ");
  res.redirect("/pymes");
};

export const renderPymes = async (req, res) => {
  const pymes = await Pyme.find({ user: req.user.id })
    .sort({ date: "desc" })
    .lean();
  res.render("pymes/all-pymes", { pymes });
};

export const renderPymess = async (req, res) => {
  const pymess = await Pyme.find({ user: req.user.id })
    .sort({ date: "desc" })
    .lean();
  res.render("pymes/all-pymes2", { pymess });
};

export const renderEditForm = async (req, res) => {
  const pyme = await Pyme.findById(req.params.id).lean();
  if (pyme.user != req.user.id) {
    req.flash("error_msg", "No autorizado");
    return res.redirect("/pymes");
  }
  res.render("pymes/edit-pyme", { pyme });
};

export const updatePyme = async (req, res) => {
  const { nombre_pyme, telefono, correo, ubicacion, descripcion, categoria } = req.body;
  await Pyme.findByIdAndUpdate(req.params.id, { nombre_pyme, telefono, correo, ubicacion, descripcion, categoria });
  req.flash("success_msg", "Pyme actualizada correctamente");
  res.redirect("/pymes");
};

export const deletePyme = async (req, res) => {
  const pyme = await Pyme.findById(req.params.id);
  if (pyme.user == req.user.id) {
    await Pyme.findByIdAndDelete(req.params.id);
    req.flash("success_msg", "Pyme borrada correctamente");
    return res.redirect("/pymes");
  }
  req.flash("error_msg", "No autorizado");
  res.redirect("/pymes")
};